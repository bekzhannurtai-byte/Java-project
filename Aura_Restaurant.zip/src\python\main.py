# from flask import Flask, render_template, request, jsonify
# import json
# import os
# import random
# from datetime import datetime
# from google import genai
# import speech_recognition as sr

# app = Flask(__name__)


# GEMINI_API_KEY = "AIzaSyDKIORZN-Pe8spkpyx3LtXDNn83ceqd2LY"

# client = genai.Client(api_key=GEMINI_API_KEY)

# class GeminiVoiceBot:
#     def __init__(self):
#         self.user_data_file = 'user_data.json'
#         self.chat_history_file = 'chat_history.json'
#         self.user_data = {}
#         self.chat_history = []
#         self.load_data()
    
#     def get_ai_response(self, user_input, user_id='default'):
#         """Получение ответа от Google Gemini AI"""
#         try:
#             print(f"📝 Отправка в Gemini: {user_input[:50]}...")
            
#             # Получаем историю для контекста
#             user_history = [msg for msg in self.chat_history 
#                            if msg.get('user_id') == user_id][-5:]
            
#             context = ""
#             for msg in user_history:
#                 context += f"Пользователь: {msg['user']}\nАқбот: {msg['bot']}\n"
            
#             # Промпт для Gemini
#             prompt = f"""Ты - Ақбот, дружелюбный и умный голосовой помощник ресторана AURA.
# Ты говоришь на русском и казахском языках.
# Ты вежливый, позитивный и готов ответить на любые вопросы.
# Отвечай кратко и по делу (2-3 предложения).

# Информация о ресторане AURA:
# - Адрес: Алматы, Медеу ауданы, ул. Абая 123
# - График: Пн-Чт 11:00-23:00, Пт-Сб 11:00-01:00, Вс 11:00-22:00
# - Меню: Бесбармак (16500₸), Куырдак (10900₸), Бауырсақ (3400₸), Қымыз (3100₸)
# - Доставка: от 5000₸, бесплатно от 10000₸
# - Телефон: +7 (777) 123-45-67

# {context}
# Пользователь: {user_input}
# Ақбот:"""
            
#             # Запрос к Gemini
#             response = client.models.generate_content(
#                 model="gemini-3-flash-preview",  # Быстрая бесплатная модель
#                 contents=prompt
#             )
            
#             print("✅ Ответ от Gemini получен")
#             return response.text
            
#         except Exception as e:
#             error_msg = str(e)
#             print(f"❌ Ошибка Gemini: {error_msg}")
            
#             if "429" in error_msg or "quota" in error_msg.lower():
#                 return """⚠️ Превышен лимит запросов Gemini.\n\nБесплатный лимит: 15 запросов/минуту. Подождите немного и попробуйте снова.\n\n💡 Пока бот работает в офлайн-режиме!"""
            
#             return self.get_offline_response(user_input)
    
#     def get_offline_response(self, user_input):
#         """Офлайн-ответы (при ошибке API)"""
#         user_lower = user_input.lower()
        
#         if any(w in user_lower for w in ["привет", "салем", "здравствуй"]):
#             return random.choice([
#                 "Привет! Я Ақбот на Google Gemini! Чем могу помочь? 😊",
#                 "Салем! Қалайсың? Я готов ответить на любые вопросы! 🎉",
#                 "Здравствуйте! Спрашивайте о чем угодно! 🌟"
#             ])
        
#         if "как дела" in user_lower:
#             return "У меня всё отлично! Google Gemini работает стабильно. А у вас?"
        
#         if "как тебя зовут" in user_lower:
#             return "Меня зовут Ақбот! Я работаю на Google Gemini AI - мощной нейросети от Google!"
        
#         if "меню" in user_lower:
#             return """🍽️ **Меню ресторана AURA:**

# 🥩 **Основные блюда:**
# • Бесбармак Көкжиек - 16 500 ₸
# • Күлгін Қуырдақ - 10 900 ₸
# • Көшпенді Табақ - 24 900 ₸

# 🥟 **Закуски:**
# • Алтын Бауырсақ - 3 400 ₸
# • Мозаика Құрт - 2 300 ₸

# 🍹 **Напитки:**
# • Аметист Шай - 4 500 ₸
# • Қара Қымыз - 3 100 ₸

# 💫 Приходите пробовать!"""
        
#         if "адрес" in user_lower:
#             return "📍 **Адрес:** Алматы, Медеу ауданы, улица Абая 123\n\n🚗 Есть парковка. Ждем вас!"
        
#         if "график" in user_lower or "работаете" in user_lower:
#             return """🕐 **График работы:**
# • Пн-Чт: 11:00 - 23:00
# • Пт-Сб: 11:00 - 01:00
# • Вс: 11:00 - 22:00

# 📞 Бронирование: +7 (777) 123-45-67"""
        
#         if "доставка" in user_lower:
#             return "🚚 **Доставка:**\n• Минимальный заказ: 5 000 ₸\n• Бесплатно от 10 000 ₸\n• Время: 40-60 минут"
        
#         if "шутка" in user_lower:
#             jokes = [
#                 "Почему программисты не любят природу? Слишком много багов! 🐛",
#                 "Как программист выходит из душа? system.out.println('Вода, выключись!') 😄",
#                 "Что сказал один бит другому? Мне тебя не хватает! 💕",
#                 "Сколько программистов нужно, чтобы заменить лампочку? Ни одного, это аппаратная проблема! 💡"
#             ]
#             return random.choice(jokes)
        
#         if "время" in user_lower:
#             return f"⏰ Сейчас {datetime.now().strftime('%H:%M')}"
        
#         if "помощь" in user_lower:
#             return """🤖 **Я умею:**

# 🎤 **Голосовой ввод** - нажмите 🎤 и скажите
# 📝 **Текстовый ввод** - просто напишите

# 💬 **Команды:**
# • меню - показать блюда и цены
# • адрес - где находится ресторан
# • график - часы работы
# • доставка - условия доставки
# • шутка - поднять настроение
# • время - текущее время

# 🚀 **На Gemini AI:**
# Отвечает на ЛЮБЫЕ вопросы! Просто спросите!"""
        
#         return "🤔 Я Ақбот на Google Gemini! Спросите меня о ресторане AURA или задайте любой вопрос - я отвечу! 🎤"
    
#     def get_response(self, user_input, user_id='default'):
#         """Главный метод получения ответа"""
#         if not user_input:
#             return "Скажите или напишите что-нибудь!"
        
#         # Запоминаем имя
#         if "меня зовут" in user_input.lower() or "менін атым" in user_input.lower():
#             words = user_input.split()
#             for i, w in enumerate(words):
#                 if w.lower() in ["зовут", "атым"] and i + 1 < len(words):
#                     name = words[i + 1]
#                     if user_id not in self.user_data:
#                         self.user_data[user_id] = {}
#                     self.user_data[user_id]['name'] = name
#                     self.save_data()
#                     return f"Очень приятно, {name}! Я запомнил ваше имя! ✨"
        
#         # Если знаем имя
#         if user_id in self.user_data and 'name' in self.user_data[user_id]:
#             name = self.user_data[user_id]['name']
#             if "как меня зовут" in user_input.lower():
#                 return f"Ваше имя - {name}! Я хорошо вас запомнил. 😊"
        
#         # Используем AI для ответа
#         return self.get_ai_response(user_input, user_id)
    
#     def add_to_history(self, user_input, bot_response, user_id='default'):
#         message = {
#             "timestamp": datetime.now().isoformat(),
#             "user_id": user_id,
#             "user": user_input,
#             "bot": bot_response
#         }
#         self.chat_history.append(message)
#         if len(self.chat_history) > 100:
#             self.chat_history = self.chat_history[-100:]
#         self.save_data()
    
#     def load_data(self):
#         try:
#             if os.path.exists(self.user_data_file):
#                 with open(self.user_data_file, 'r', encoding='utf-8') as f:
#                     self.user_data = json.load(f)
#             if os.path.exists(self.chat_history_file):
#                 with open(self.chat_history_file, 'r', encoding='utf-8') as f:
#                     self.chat_history = json.load(f)
#         except:
#             pass
    
#     def save_data(self):
#         try:
#             with open(self.user_data_file, 'w', encoding='utf-8') as f:
#                 json.dump(self.user_data, f, ensure_ascii=False, indent=2)
#             with open(self.chat_history_file, 'w', encoding='utf-8') as f:
#                 json.dump(self.chat_history, f, ensure_ascii=False, indent=2)
#         except:
#             pass

# bot = GeminiVoiceBot()

# @app.route('/')
# def index():
#     return render_template('chat.html')

# @app.route('/chat', methods=['POST'])
# def chat():
#     try:
#         data = request.json
#         user_input = data.get('message', '')
#         user_id = data.get('user_id', 'default')
        
#         response = bot.get_response(user_input, user_id)
#         bot.add_to_history(user_input, response, user_id)
        
#         return jsonify({'success': True, 'response': response})
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/voice', methods=['POST'])
# def voice():
#     """Голосовой ввод"""
#     try:
#         recognizer = sr.Recognizer()
#         with sr.Microphone() as source:
#             print("🎤 Слушаю...")
#             recognizer.adjust_for_ambient_noise(source, duration=0.5)
#             audio = recognizer.listen(source, timeout=5, phrase_time_limit=5)
#             text = recognizer.recognize_google(audio, language="ru-RU")
#             print(f"✅ Распознано: {text}")
#             return jsonify({'success': True, 'text': text})
#     except sr.WaitTimeoutError:
#         return jsonify({'success': False, 'error': 'Ничего не услышано'})
#     except sr.UnknownValueError:
#         return jsonify({'success': False, 'error': 'Не удалось распознать'})
#     except Exception as e:
#         return jsonify({'error': str(e)}), 500

# @app.route('/history', methods=['GET'])
# def history():
#     user_id = request.args.get('user_id', 'default')
#     user_history = [msg for msg in bot.chat_history if msg.get('user_id') == user_id]
#     return jsonify({'success': True, 'history': user_history[-50:]})

# @app.route('/reset', methods=['POST'])
# def reset():
#     data = request.json
#     user_id = data.get('user_id', 'default')
#     if user_id in bot.user_data:
#         del bot.user_data[user_id]
#         bot.save_data()
#     return jsonify({'success': True})

# @app.route('/stats', methods=['GET'])
# def stats():
#     return jsonify({
#         'success': True,
#         'total_users': len(bot.user_data),
#         'total_messages': len(bot.chat_history)
#     })

# if __name__ == '__main__':
#     print("=" * 60)
#     print("🤖 Чат-бот Ақбот на Google Gemini AI")
#     print("=" * 60)
#     print("📱 http://127.0.0.1:5000")
#     print("")
#     print("🔑 API КЛЮЧ: AIzaSyDKIORZN-Pe8spkpyx3LtXDNn83ceqd2LY")
#     print("")
#     print("💡 Google Gemini AI возможности:")
#     print("   • Отвечает на ЛЮБЫЕ вопросы")
#     print("   • Помогает решать задачи")
#     print("   • Работает как ChatGPT")
#     print("   • Бесплатный лимит: 15 запросов/минуту")
#     print("")
#     print("🎤 Голосовой ввод:")
#     print("   • Нажмите кнопку 🎤 в чате")
#     print("   • Разрешите доступ к микрофону")
#     print("   • Скажите вопрос")
#     print("")
#     print("🚀 Бот готов к работе!")
#     print("=" * 60)
#     app.run(debug=True)




# -*- coding: utf-8 -*-
# Цезарь шифрі (вариант 2: k = 5)

# def create_alphabet():
#     """Қазақ әліпбиін жасау"""
#     lower = 'aäbcçdeéfghiıjklmnñoöpqrstuüvwxyýz'
#     upper = lower.upper()
#     return lower + upper

# def caesar_encrypt(text, shift, alphabet):
#     """Мәтінді шифрлау"""
#     result = []
#     for char in text:
#         if char in alphabet:
#             old_index = alphabet.index(char)
#             new_index = (old_index + shift) % len(alphabet)
#             result.append(alphabet[new_index])
#         else:
#             result.append(char)
#     return ''.join(result)

# def caesar_decrypt(text, shift, alphabet):
#     """Мәтінді кері шифрлау"""
#     result = []
#     for char in text:
#         if char in alphabet:
#             old_index = alphabet.index(char)
#             new_index = (old_index - shift) % len(alphabet)
#             result.append(alphabet[new_index])
#         else:
#             result.append(char)
#     return ''.join(result)

# # Бағдарламаны тестілеу
# if __name__ == "__main__":
#     alphabet = create_alphabet()
#     key = 5
    
#     test_text = "Сәлем, Қазақстан!"
#     print(f"Бастапқы мәтін: {test_text}")
    
#     encrypted = caesar_encrypt(test_text, key, alphabet)
#     print(f"Шифрланған мәтін (k={key}): {encrypted}")
    
#     decrypted = caesar_decrypt(encrypted, key, alphabet)
#     print(f"Кері шифрланған мәтін: {decrypted}")




# -*- coding: utf-8 -*-
# RSA алгоритмі

# import random
# import math

# def is_prime(num, k=5):
#     """Миллер-Рабин тесті арқылы жай санды тексеру"""
#     if num < 2:
#         return False
#     if num in (2, 3):
#         return True
#     if num % 2 == 0:
#         return False
    
#     r, s = 0, num - 1
#     while s % 2 == 0:
#         r += 1
#         s //= 2
    
#     for _ in range(k):
#         a = random.randint(2, num - 1)
#         x = pow(a, s, num)
#         if x == 1 or x == num - 1:
#             continue
#         for _ in range(r - 1):
#             x = pow(x, 2, num)
#             if x == num - 1:
#                 break
#         else:
#             return False
#     return True

# def generate_prime(bits=8):
#     """Жай санды генерациялау"""
#     while True:
#         num = random.getrandbits(bits)
#         num |= (1 << bits - 1) | 1
#         if is_prime(num):
#             return num

# def egcd(a, b):
#     """Кеңейтілген Евклид алгоритмі"""
#     if a == 0:
#         return b, 0, 1
#     gcd, x1, y1 = egcd(b % a, a)
#     x = y1 - (b // a) * x1
#     y = x1
#     return gcd, x, y

# def generate_keys(bits=8):
#     """RSA кілттерін генерациялау"""
#     p = generate_prime(bits)
#     q = generate_prime(bits)
#     while p == q:
#         q = generate_prime(bits)
    
#     n = p * q
#     phi = (p - 1) * (q - 1)
    
#     e = 65537
#     if e >= phi:
#         e = 17
#     while math.gcd(e, phi) != 1:
#         e += 2
    
#     _, d, _ = egcd(e, phi)
#     d = d % phi
#     if d < 0:
#         d += phi
    
#     return (e, n), (d, n)

# def encrypt_file(input_file, output_file, public_key):
#     """Файлды шифрлау"""
#     e, n = public_key
#     with open(input_file, 'rb') as f:
#         data = f.read()
    
#     encrypted_data = []
#     for byte in data:
#         c = pow(byte, e, n)
#         encrypted_data.append(c.to_bytes((n.bit_length() + 7) // 8, 'big'))
    
#     with open(output_file, 'wb') as f:
#         for block in encrypted_data:
#             f.write(block)

# def decrypt_file(input_file, output_file, private_key):
#     """Файлды кері шифрлау"""
#     d, n = private_key
#     block_size = (n.bit_length() + 7) // 8
    
#     with open(input_file, 'rb') as f:
#         encrypted_data = f.read()
    
#     decrypted_data = []
#     for i in range(0, len(encrypted_data), block_size):
#         block = encrypted_data[i:i+block_size]
#         c = int.from_bytes(block, 'big')
#         m = pow(c, d, n)
#         decrypted_data.append(m.to_bytes(1, 'big'))
    
#     with open(output_file, 'wb') as f:
#         for byte in decrypted_data:
#             f.write(byte)

# # Бағдарламаны тестілеу
# if __name__ == "__main__":
#     print("=" * 50)
#     print("RSA АЛГОРИТМІН ТЕСТІЛЕУ")
#     print("=" * 50)
    
#     # Кілттерді генерациялау
#     public_key, private_key = generate_keys(bits=16)
#     print(f"\nАшық кілт (e, n): {public_key}")
#     print(f"Жабық кілт (d, n): {private_key}")
    
#     # Тест файлын жасау
#     test_content = "RSA алгоритмінің жұмысын тексеру. Сәлем, әлем!"
#     with open("test.txt", "w", encoding="utf-8") as f:
#         f.write(test_content)
#     print(f"\nБастапқы файл (test.txt): {test_content}")
    
#     # Шифрлау
#     encrypt_file("test.txt", "encrypted.bin", public_key)
#     print("Шифрлау аяқталды -> encrypted.bin")
    
#     # Кері шифрлау
#     decrypt_file("encrypted.bin", "decrypted.txt", private_key)
#     print("Кері шифрлау аяқталды -> decrypted.txt")
    
#     # Нәтижені тексеру
#     with open("decrypted.txt", "r", encoding="utf-8") as f:
#         decrypted_content = f.read()
#     print(f"\nКері шифрланған мәтін: {decrypted_content}")
    
#     # Сәйкестікті тексеру
#     if test_content == decrypted_content:
#         print("\n Нәтиже: Бастапқы мәтін мен кері шифрланған мәтін сәйкес келеді!")
#     else:
#         print("\n Қате: Мәтіндер сәйкес келмейді!")





# import random
# import math

# # Қарапайым сандарды тексеру
# def is_prime(n, k=5):
#     if n < 2:
#         return False
#     if n in (2, 3):
#         return True
#     if n % 2 == 0:
#         return False
    
#     # Миллер-Рабин тесті
#     r, s = 0, n - 1
#     while s % 2 == 0:
#         r += 1
#         s //= 2
    
#     for _ in range(k):
#         a = random.randint(2, n - 2)
#         x = pow(a, s, n)
#         if x == 1 or x == n - 1:
#             continue
#         for _ in range(r - 1):
#             x = pow(x, 2, n)
#             if x == n - 1:
#                 break
#         else:
#             return False
#     return True

# # Кездейсоқ жай сан генерациялау
# def generate_prime(bits=8):
#     while True:
#         num = random.randint(2**(bits-1), 2**bits)
#         if is_prime(num):
#             return num

# # Евклидтің кеңейтілген алгоритмі (кері элемент табу)
# def mod_inverse(e, phi):
#     def egcd(a, b):
#         if a == 0:
#             return (b, 0, 1)
#         else:
#             g, y, x = egcd(b % a, a)
#             return (g, x - (b // a) * y, y)
    
#     g, x, y = egcd(e, phi)
#     if g != 1:
#         return None
#     return x % phi

# # RSA кілттерін генерациялау
# def generate_rsa_keys(bits=8):
#     p = generate_prime(bits)
#     q = generate_prime(bits)
#     while p == q:
#         q = generate_prime(bits)
    
#     n = p * q
#     phi = (p - 1) * (q - 1)
    
#     e = 65537  # жиі қолданылатын мән
#     if e >= phi:
#         e = 3
#     while math.gcd(e, phi) != 1:
#         e += 2
    
#     d = mod_inverse(e, phi)
#     return (e, n), (d, n), (p, q)

# # Сандық қолтаңба жасау
# def sign(message, private_key):
#     d, n = private_key
#     # Хабардың хэші (қарапайымдылық үшін хабардың өзін аламыз)
#     hash_msg = hash(message) % n
#     signature = pow(hash_msg, d, n)
#     return signature

# # Қолтаңбаны тексеру
# def verify(message, signature, public_key):
#     e, n = public_key
#     hash_msg = hash(message) % n
#     decrypted_hash = pow(signature, e, n)
#     return decrypted_hash == hash_msg

# # Негізгі бағдарлама
# def main():
#     print("=" * 50)
#     print("RSA Электронды цифрлық қолтаңба (ЭЦҚ) жүйесі")
#     print("=" * 50)
    
#     # 1. Кілттерді генерациялау
#     print("\n1. Кілттерді генерациялау...")
#     public_key, private_key, primes = generate_rsa_keys(bits=16)
#     e, n = public_key
#     d, _ = private_key
#     p, q = primes
#     print(f"   Жай сандар: p = {p}, q = {q}")
#     print(f"   n = {n}")
#     print(f"   Ашық кілт (e, n): ({e}, {n})")
#     print(f"   Жабық кілт (d, n): ({d}, {n})")
    
#     # 2. Хабарды енгізу
#     message = input("\n2. Қолтаңба қоятын хабарды енгізіңіз: ")
    
#     # 3. Қолтаңба жасау
#     signature = sign(message, private_key)
#     print(f"\n3. Жасалған қолтаңба: {signature}")
    
#     # 4. Қолтаңбаны тексеру
#     print("\n4. Қолтаңбаны тексеру...")
#     is_valid = verify(message, signature, public_key)
    
#     if is_valid:
#         print("   ✅ Қолтаңба ДҰРЫС! Хабар өзгертілмеген.")
#     else:
#         print("   ❌ Қолтаңба ЖАЛҒАН! Хабар бұрмаланған.")
    
#     # 5. Бұрмалау тесті
#     print("\n5. Бұрмалау тесті (қолтаңбаны өзгертсек):")
#     fake_signature = signature + 1
#     is_valid_fake = verify(message, fake_signature, public_key)
#     if not is_valid_fake:
#         print("   ✅ Өзгертілген қолтаңба анықталды!")
    
#     print("\n" + "=" * 50)
#     print("Жұмыс аяқталды.")

# if __name__ == "__main__":
#     main()





import math
import time
import hashlib
from datetime import datetime

# ============================================================
# ТАПСЫРМА 1: Классикалық аутентификация протоколы
# ============================================================

class ClassicAuthentication:
    """Классикалық аутентификация протоколы (логин + пароль)"""
    
    def __init__(self):
        # Дерекқор: логин -> парольдің хэші
        self.database = {
            "user123": hashlib.sha256("mypassword123".encode()).hexdigest(),
            "almaty_user": hashlib.sha256("almaty2024".encode()).hexdigest()
        }
    
    def authenticate(self, login, password):
        """Аутентификация процесі"""
        print(f"\n--- Аутентификация протоколы ---")
        print(f"1. Сәйкестендіру: логин '{login}' енгізілді")
        
        if login not in self.database:
            print("5. Шешім: ҚОЛЖЕТІМДІЛІК БАС ТАРТЫЛДЫ (логин жоқ)")
            return False
        
        print(f"2. Шақыру: парольді енгізіңіз")
        print(f"3. Жауап: пароль енгізілді")
        
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        
        print(f"4. Тексеру: пароль хэшін салыстыру...")
        
        if password_hash == self.database[login]:
            print("5. Шешім: ҚОЛЖЕТІМДІЛІК БЕРІЛДІ ✓")
            return True
        else:
            print("5. Шешім: ҚОЛЖЕТІМДІЛІК БАС ТАРТЫЛДЫ (қате пароль) ✗")
            return False


# ============================================================
# ТАПСЫРМА 2: Қолтаңба негізіндегі биометриялық аутентификация
# ============================================================

class SignatureBiometricAuth:
    """Қолтаңба негізіндегі биометриялық аутентификация жүйесі"""
    
    def __init__(self, user_name="Қолданушы"):
        self.user_name = user_name
        self.templates = []           # Қолтаңба үлгілері
        self.reference_profile = {}   # Эталондық профиль
        self.threshold = 0.70         # Сәйкестік шегі (70%)
        
        # Параметрлер салмағы
        self.weights = {
            'speed': 0.25,        # Жылдамдық
            'avg_letter_size': 0.20,  # Әріп өлшемі
            'avg_pressure': 0.20,     # Қысым
            'curvature': 0.20,    # Қисықтық
            'rhythm_std': 0.15    # Ритм
        }
    
    def analyze_signature(self, phrase, write_time_ms, letter_sizes, pressures, curvature, intervals):
        """Қолтаңбаны талдау және параметрлерді алу"""
        
        speed = len(phrase) / (write_time_ms / 1000) if write_time_ms > 0 else 0
        avg_letter_size = sum(letter_sizes) / len(letter_sizes) if letter_sizes else 0
        avg_pressure = sum(pressures) / len(pressures) if pressures else 0
        
        if len(intervals) > 1:
            mean_interval = sum(intervals) / len(intervals)
            rhythm_std = math.sqrt(sum((i - mean_interval) ** 2 for i in intervals) / len(intervals))
        else:
            rhythm_std = 0
        
        return {
            'phrase': phrase,
            'length': len(phrase),
            'write_time_ms': write_time_ms,
            'speed': speed,
            'avg_letter_size': avg_letter_size,
            'avg_pressure': avg_pressure,
            'curvature': curvature,
            'rhythm_std': rhythm_std,
            'timestamp': datetime.now().strftime("%H:%M:%S")
        }
    
    def enroll(self, phrase, n_samples=5):
        """1-2. Қолданушы бақылау фразасын бірнеше рет жазады. Жүйе үлгілерді сақтайды."""
        
        print(f"\n{'='*60}")
        print(f"ҚОЛТАҢБАНЫ ТІРКЕУ (ENROLLMENT)")
        print(f"{'='*60}")
        print(f"Қолданушы: {self.user_name}")
        print(f"Бақылау фразасы: '{phrase}'")
        print(f"Қайталау саны: {n_samples} рет\n")
        
        self.templates = []
        
        for i in range(1, n_samples + 1):
            print(f"--- {i}-ші жазу ---")
            
            # Симуляция: әр жазбада параметрлер аздап өзгереді
            variation = 1 + (i - 3) * 0.02
            
            write_time_ms = len(phrase) * (140 + (i % 3) * 5) * variation
            letter_sizes = [(ord(c) % 10 + 5) + (i % 3) for c in phrase]
            pressures = [55 + (ord(c) % 40) + (i % 8) for c in phrase]
            curvature = (sum(ord(c) for c in phrase) % 200) / 10 + (i * 0.1)
            intervals = [140 + (j * 8) + (i * 2) for j in range(len(phrase))]
            
            features = self.analyze_signature(phrase, write_time_ms, letter_sizes, pressures, curvature, intervals)
            self.templates.append(features)
            
            print(f"  Жазу уақыты: {features['write_time_ms']:.0f} мс")
            print(f"  Жылдамдық: {features['speed']:.2f} әр/с")
            print(f"  Орташа әріп өлшемі: {features['avg_letter_size']:.1f}")
            print(f"  Орташа қысым: {features['avg_pressure']:.1f}")
            print(f"  Қисықтық: {features['curvature']:.1f}")
            print(f"  Ритм (Std): {features['rhythm_std']:.1f} мс\n")
            
            time.sleep(0.2)
        
        self.reference_profile = self._compute_reference_profile()
        self.control_phrase = phrase
        
        print(f"{'='*60}")
        print(f"✓ ТІРКЕУ СӘТТІ АЯҚТАЛДЫ!")
        print(f"{'='*60}")
        self._print_reference_profile()
        
        return True
    
    def _compute_reference_profile(self):
        """Эталондық профильді есептеу (орташа мәндер және ауытқулар)"""
        profile = {}
        keys = ['speed', 'avg_letter_size', 'avg_pressure', 'curvature', 'rhythm_std']
        
        for key in keys:
            values = [t[key] for t in self.templates]
            mean = sum(values) / len(values)
            variance = sum((v - mean) ** 2 for v in values) / len(values)
            std = math.sqrt(variance)
            profile[key] = mean
            profile[f'{key}_std'] = std
        
        return profile
    
    def _print_reference_profile(self):
        """Эталондық профильді көрсету"""
        print("\nЭТАЛОНДЫҚ ПРОФИЛЬ (5 жазба бойынша):")
        print(f"┌─────────────────────┬────────────────┬────────────────┐")
        print(f"│ Параметр            │ Орташа мән     │ Ауытқу (±)     │")
        print(f"├─────────────────────┼────────────────┼────────────────┤")
        print(f"│ Жылдамдық (әр/с)    │ {self.reference_profile['speed']:.2f}        │ {self.reference_profile['speed_std']:.3f}          │")
        print(f"│ Әріп өлшемі         │ {self.reference_profile['avg_letter_size']:.2f}         │ {self.reference_profile['avg_letter_size_std']:.3f}          │")
        print(f"│ Қысым               │ {self.reference_profile['avg_pressure']:.2f}        │ {self.reference_profile['avg_pressure_std']:.3f}          │")
        print(f"│ Қисықтық            │ {self.reference_profile['curvature']:.2f}        │ {self.reference_profile['curvature_std']:.3f}          │")
        print(f"│ Ритм (мс)           │ {self.reference_profile['rhythm_std']:.2f}        │ {self.reference_profile['rhythm_std_std']:.3f}          │")
        print(f"└─────────────────────┴────────────────┴────────────────┘")
    
    def verify(self, phrase):
        """3. Жаңа үлгіні эталондық деректермен салыстыру"""
        
        print(f"\n{'='*60}")
        print(f"АУТЕНТИФИКАЦИЯ (VERIFICATION)")
        print(f"{'='*60}")
        print(f"Бақылау фразасын жазыңыз: '{phrase}'")
        
        variation = 0.92 + (hash(phrase) % 15) / 100
        
        write_time_ms = len(phrase) * 145 * variation
        letter_sizes = [(ord(c) % 10 + 5) + int(variation * 2) for c in phrase]
        pressures = [55 + (ord(c) % 40) + int(8 * variation) for c in phrase]
        curvature = (sum(ord(c) for c in phrase) % 200) / 10 * (0.95 + variation * 0.1)
        intervals = [140 + (j * 8) + int(15 * variation) for j in range(len(phrase))]
        
        new_features = self.analyze_signature(phrase, write_time_ms, letter_sizes, pressures, curvature, intervals)
        
        print(f"\nЖАҢА ҮЛГІ ПАРАМЕТРЛЕРІ:")
        print(f"  Жазу уақыты: {new_features['write_time_ms']:.0f} мс")
        print(f"  Жылдамдық: {new_features['speed']:.2f} әр/с")
        print(f"  Әріп өлшемі: {new_features['avg_letter_size']:.1f}")
        print(f"  Қысым: {new_features['avg_pressure']:.1f}")
        print(f"  Қисықтық: {new_features['curvature']:.1f}")
        print(f"  Ритм: {new_features['rhythm_std']:.1f} мс")
        
        match_score = self._calculate_match_score(new_features)
        
        print(f"\nСӘЙКЕСТІК ТАЛДАУЫ:")
        
        for param, weight in self.weights.items():
            if param in self.reference_profile:
                ref_mean = self.reference_profile[param]
                ref_std = self.reference_profile.get(f'{param}_std', 1)
                new_val = new_features[param]
                if ref_std > 0:
                    z_score = abs(new_val - ref_mean) / ref_std
                    param_score = max(0, 1 - min(1, z_score / 2.5))
                    status = "✓" if param_score > 0.7 else "⚠" if param_score > 0.4 else "✗"
                    print(f"  {status} {param}: {param_score:.1%} (z={z_score:.2f})")
        
        print(f"\n  Сәйкестік деңгейі: {match_score:.1%}")
        print(f"  Шекті мән: {self.threshold:.1%}")
        
        # 4. Параметрлер сәйкес келсе, қолжетімділік беріледі
        if match_score >= self.threshold:
            print(f"\n{'='*60}")
            print(f"✅ ҚОЛЖЕТІМДІЛІК БЕРІЛДІ!")
            print(f"Қолтаңба сәйкес келді.")
            print(f"{'='*60}")
            return True, match_score
        else:
            print(f"\n{'='*60}")
            print(f"❌ ҚОЛЖЕТІМДІЛІК БАС ТАРТЫЛДЫ!")
            print(f"Қолтаңба сәйкес келмеді.")
            print(f"{'='*60}")
            return False, match_score
    
    def _calculate_match_score(self, new_features):
        """Сәйкестік дәрежесін есептеу"""
        total_score = 0
        total_weight = 0
        
        for param, weight in self.weights.items():
            if param in self.reference_profile:
                ref_mean = self.reference_profile[param]
                ref_std = self.reference_profile.get(f'{param}_std', 1)
                new_val = new_features[param]
                
                if ref_std > 0:
                    z_score = abs(new_val - ref_mean) / ref_std
                    param_score = max(0, 1 - min(1, z_score / 2.5))
                else:
                    param_score = 1.0 if abs(new_val - ref_mean) < 0.1 else 0.5
                
                total_score += param_score * weight
                total_weight += weight
        
        return total_score / total_weight if total_weight > 0 else 0


# ============================================================
# ТАПСЫРМА 3: Салыстыру
# ============================================================

def compare_methods():
    """Құпия сөз және биометриялық аутентификацияны салыстыру"""
    
    print("\n" + "="*70)
    print("ТАПСЫРМА 3: Құпия сөз және биометриялық аутентификацияны салыстыру")
    print("="*70)
    
    print("\n┌" + "─"*68 + "┐")
    print("│{:^68}│".format("ҚҰПИЯ СӨЗ vs БИОМЕТРИЯЛЫҚ АУТЕНТИФИКАЦИЯ"))
    print("├" + "─"*20 + "┬" + "─"*22 + "┬" + "─"*22 + "┤")
    print("│{:^20}│{:^22}│{:^22}│".format("Критерий", "Құпия сөз", "Биометрия"))
    print("├" + "─"*20 + "┼" + "─"*22 + "┼" + "─"*22 + "┤")
    
    comparison = {
        "Қауіпсіздік деңгейі": ("Орташа", "Жоғары"),
        "Ұрлау қаупі": ("Жоғары", "Төмен"),
        "Жады қажеттілігі": ("Иә", "Жоқ"),
        "Қателік ықтималдығы": ("Төмен", "Орташа"),
        "Қайталану мүмкіндігі": ("Жоғары", "Төмен"),
        "Құны": ("Төмен", "Жоғары"),
        "Пайдалану ыңғайлылығы": ("Орташа", "Жоғары"),
        "Өзгерту мүмкіндігі": ("Иә", "Жоқ"),
        "Қосымша жабдық": ("Қажет емес", "Қажет")
    }
    
    for criterion, (password, bio) in comparison.items():
        print("│{:<20}│{:<22}│{:<22}│".format(criterion, password, bio))
        print("├" + "─"*20 + "┼" + "─"*22 + "┼" + "─"*22 + "┤")
    
    print("│{:^68}│".format("ҚОРЫТЫНДЫ"))
    print("├" + "─"*68 + "┤")
    print("│{:<68}│".format("• Парольдік аутентификация — арзан, бірақ ұрлауға бейім"))
    print("│{:<68}│".format("• Биометриялық аутентификация — қауіпсізірек, бірақ қымбатырақ"))
    print("│{:<68}│".format("• Ең жақсы нұсқа — көпфакторлы аутентификация"))
    print("└" + "─"*68 + "┘")


# ============================================================
# НЕГІЗГІ БАҒДАРЛАМА
# ============================================================

def main():
    print("="*60)
    print("№8 ЗЕРТХАНАЛЫҚ ЖҰМЫС")
    print("Аутентификация протоколы. Қолтаңба негізіндегі биометрия")
    print("="*60)
    
    # ===== ТАПСЫРМА 1 =====
    print("\n" + "█"*60)
    print("ТАПСЫРМА 1: Классикалық аутентификация протоколы")
    print("█"*60)
    
    classic_auth = ClassicAuthentication()
    classic_auth.authenticate("user123", "mypassword123")
    classic_auth.authenticate("user123", "wrongpass")
    
    # ===== ТАПСЫРМА 2 =====
    print("\n" + "█"*60)
    print("ТАПСЫРМА 2: Қолтаңба негізіндегі биометриялық аутентификация")
    print("█"*60)
    
    bio_auth = SignatureBiometricAuth("Асан Қайратұлы")
    
    # 1-2. Тіркеу
    bio_auth.enroll("АЛМАТЫ", n_samples=5)
    
    # 3-4. Дұрыс қолтаңбаны тексеру
    print("\n" + "►"*30)
    print("ДҰРЫС ҚОЛТАҢБАНЫ ТЕКСЕРУ")
    print("◄"*30)
    bio_auth.verify("АЛМАТЫ")
    
    # Бұтақ қолтаңбаны тексеру
    print("\n" + "►"*30)
    print("БҰТАҚ ҚОЛТАҢБАНЫ ТЕКСЕРУ")
    print("◄"*30)
    bio_auth.verify("АСТАНА")
    
    # ===== ТАПСЫРМА 3 =====
    compare_methods()
    
    print("\n" + "="*60)
    print("ЖҰМЫС АЯҚТАЛДЫ")
    print("="*60)


if __name__ == "__main__":
    main()