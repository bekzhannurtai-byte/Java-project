import speech_recognition as sr
import webbrowser
import os
import subprocess
import datetime
import pyttsx3
import random

class VoiceAssistant:
    def __init__(self):
        # Инициализация распознавателя
        self.recognizer = sr.Recognizer()
        
        # Инициализация голосового движка
        self.engine = pyttsx3.init()
        self.setup_voice()
        
        # Словарь команд
        self.commands = {
            "привет": self.greet,
            "здравствуй": self.greet,
            "салем": self.greet,
            "как дела": self.how_are_you,
            "как ты": self.how_are_you,
            "время": self.show_time,
            "сколько времени": self.show_time,
            "дата": self.show_date,
            "какое сегодня число": self.show_date,
            "открой браузер": self.open_browser,
            "google": self.open_browser,
            "открой блокнот": self.open_notepad,
            "notepad": self.open_notepad,
            "калькулятор": self.open_calculator,
            "калькулятор открой": self.open_calculator,
            "поиск": self.search_google,
            "найди": self.search_google,
            "шутка": self.tell_joke,
            "расскажи шутку": self.tell_joke,
            "погода": self.weather,
            "какая погода": self.weather,
            "справка": self.show_help,
            "помощь": self.show_help,
            "что ты умеешь": self.show_help,
            "пока": self.exit,
            "до свидания": self.exit,
            "выход": self.exit
        }
        
        self.is_running = True
    
    def setup_voice(self):
        """Настройка голоса"""
        # Получаем доступные голоса
        voices = self.engine.getProperty('voices')
        
        # Выбираем русский голос, если есть
        for voice in voices:
            if 'russian' in voice.name.lower() or 'russian' in voice.languages:
                self.engine.setProperty('voice', voice.id)
                break
        
        # Настройка скорости и громкости
        self.engine.setProperty('rate', 150)  # Скорость речи
        self.engine.setProperty('volume', 0.9)  # Громкость
    
    def speak(self, text):
        """Озвучивание текста"""
        print(f"🤖 Ассистент: {text}")
        self.engine.say(text)
        self.engine.runAndWait()
    
    def listen(self):
        """Прослушивание голоса"""
        try:
            with sr.Microphone() as source:
                print("\n🎤 Слушаю... (скажите команду)")
                
                # Адаптация к шуму
                self.recognizer.adjust_for_ambient_noise(source, duration=0.5)
                
                # Слушаем
                audio = self.recognizer.listen(source, timeout=5, phrase_time_limit=5)
                
                # Распознаем
                text = self.recognizer.recognize_google(audio, language="ru-RU")
                print(f"👤 Вы сказали: {text}")
                return text.lower()
                
        except sr.WaitTimeoutError:
            print("⏰ Ничего не услышано")
            return None
        except sr.UnknownValueError:
            print("❌ Не распознано")
            return None
        except sr.RequestError:
            print("❌ Ошибка подключения к сервису")
            return None
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return None
    
    def process_command(self, command):
        """Обработка команды"""
        if not command:
            return
        
        # Ищем команду в словаре
        for cmd_key, cmd_func in self.commands.items():
            if cmd_key in command:
                cmd_func(command)
                return
        
        # Если команда не найдена
        self.speak("Извините, я не понял команду. Скажите 'помощь', чтобы увидеть список команд.")
    
    # --- Команды ---
    def greet(self, command=""):
        responses = [
            "Привет! Чем могу помочь?",
            "Здравствуйте! Рад вас видеть!",
            "Салем! Как дела?"
        ]
        self.speak(random.choice(responses))
    
    def how_are_you(self, command=""):
        self.speak("У меня всё отлично! Спасибо, что спросили. А как у вас дела?")
    
    def show_time(self, command=""):
        now = datetime.datetime.now()
        time_str = now.strftime("%H часов %M минут")
        self.speak(f"Сейчас {time_str}")
    
    def show_date(self, command=""):
        today = datetime.datetime.now()
        date_str = today.strftime("%d %B %Y года")
        self.speak(f"Сегодня {date_str}")
    
    def open_browser(self, command=""):
        self.speak("Открываю браузер")
        webbrowser.open("https://www.google.com")
    
    def open_notepad(self, command=""):
        self.speak("Открываю блокнот")
        os.system("notepad.exe")
    
    def open_calculator(self, command=""):
        self.speak("Открываю калькулятор")
        os.system("calc.exe")
    
    def search_google(self, command):
        # Извлекаем поисковый запрос
        query = command.replace("поиск", "").replace("найди", "").strip()
        if query:
            self.speak(f"Ищу {query}")
            url = f"https://www.google.com/search?q={query}"
            webbrowser.open(url)
        else:
            self.speak("Что вы хотите найти?")
    
    def tell_joke(self, command=""):
        jokes = [
            "Почему программисты путают Хэллоуин и Рождество? Потому что 31 Oct = 25 Dec!",
            "Как программист выходит из душа? system.out.println('Вода, выключись!')",
            "Что сказал один бит другому? Мне тебя не хватает!",
            "Сколько программистов нужно, чтобы заменить лампочку? Ни одного, это аппаратная проблема!"
        ]
        self.speak(random.choice(jokes))
    
    def weather(self, command=""):
        self.speak("Я не имею доступа к данным о погоде. Рекомендую посмотреть прогноз на Gismeteo или Yandex.Погода")
    
    def show_help(self, command=""):
        help_text = """
        Я умею выполнять следующие команды:
        • Привет, как дела, как ты
        • Время, дата
        • Открой браузер, открой блокнот, калькулятор
        • Поиск [что искать]
        • Шутка, расскажи шутку
        • Погода, какая погода
        • Пока, до свидания, выход
        """
        self.speak(help_text)
    
    def exit(self, command=""):
        self.speak("До свидания! Рад был помочь!")
        self.is_running = False
    
    # --- Запуск ---
    def run(self):
        """Запуск голосового ассистента"""
        print("=" * 60)
        print("🎙️ ГОЛОСОВОЙ АССИСТЕНТ v1.0")
        print("=" * 60)
        self.speak("Голосовой ассистент активирован. Скажите 'помощь' для списка команд.")
        
        while self.is_running:
            command = self.listen()
            if command:
                self.process_command(command)

# Запуск ассистента
if __name__ == "__main__":
    assistant = VoiceAssistant()
    assistant.run()