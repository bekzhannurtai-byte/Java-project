import speech_recognition as sr

def recognize_speech():
    """Простая функция распознавания речи"""
    
    # Создаем объект распознавателя
    recognizer = sr.Recognizer()
    
    # Используем микрофон как источник звука
    with sr.Microphone() as source:
        print("🎤 Слушаю... Говорите!")
        
        # Адаптируемся к уровню шума (1 секунда)
        print("Адаптация к шуму...")
        recognizer.adjust_for_ambient_noise(source, duration=1)
        
        # Слушаем голос
        print("Говорите сейчас...")
        try:
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=5)
            print("🔄 Обработка...")
            
            # Распознаем голос (Google Speech Recognition)
            # Можно выбрать язык: ru-RU, kk-KZ, en-US
            text = recognizer.recognize_google(audio, language="ru-RU")
            print(f"✅ Вы сказали: {text}")
            return text
            
        except sr.WaitTimeoutError:
            print("⏰ Время ожидания истекло. Попробуйте снова.")
            return None
        except sr.UnknownValueError:
            print("❌ Не удалось распознать голос. Попробуйте говорить четче.")
            return None
        except sr.RequestError as e:
            print(f"❌ Ошибка подключения: {e}")
            return None
        except Exception as e:
            print(f"❌ Ошибка: {e}")
            return None

# Запуск программы
if __name__ == "__main__":
    print("=" * 50)
    print("🎙️ Голосовой интерфейс v1.0")
    print("Скажите что-нибудь...")
    print("=" * 50)
    
    result = recognize_speech()
    if result:
        print(f"\n📝 Распознанный текст: {result}")